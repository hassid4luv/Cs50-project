// static/app.js
document.addEventListener('DOMContentLoaded', function () {
    // Your JavaScript code goes here
    console.log('App loaded!');

    // Example: Add a click event listener to a button with ID 'logoutBtn'
    var logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function () {
            // You can add additional functionality here, like making an AJAX request to log the user out on the server
            console.log('Logout button clicked!');
        });
    }
});
